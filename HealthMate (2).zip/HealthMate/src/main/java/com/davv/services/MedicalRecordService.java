package com.davv.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.davv.dao.SessionBuilder;
import com.davv.entities.Doctor;
import com.davv.entities.Laboratory;
import com.davv.entities.MedicalRecord;
import com.davv.entities.Patient;
import com.davv.entities.User;
import com.davv.model.UserRegisterModel;

@Component
public class MedicalRecordService 
{
	@Autowired
	private SessionBuilder sessBuilder;
	
	public String save(MedicalRecord rec) 
	{
		Session sess = null;
		try {
			sess= sessBuilder.getSess();
			
			sess.save(rec);
			sess.beginTransaction().commit();
			return "Record Successfully Done.";
		}catch(Exception ex) {
			ex.printStackTrace();
			return "Record Save Failed , " + ex.getMessage();
		}finally {
			sess.close();
		}
	}

	public List<MedicalRecord> getPatientRecords(Patient patient) 
	{
		Session sess= sessBuilder.getSess();
		
		Query<MedicalRecord> qu = sess.createQuery("from MedicalRecord where patient=?1");
		qu.setParameter(1, patient);
			
		List<MedicalRecord> list = qu.list();
		
		sess.close();
		return list;
	}

	public void approve(Integer id) {
		Session sess= sessBuilder.getSess();
		MedicalRecord rec = sess.get(MedicalRecord.class, id);
		if(rec!=null) {
			rec.setIsApproved(true);
			sess.update(rec);
			sess.beginTransaction().commit();
		}
	}
}
