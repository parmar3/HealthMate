package com.davv.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.davv.dao.SessionBuilder;

import com.davv.entities.Laboratory;

import com.davv.entities.Patient;
import com.davv.entities.PatientDocument;
import com.davv.entities.User;
import com.davv.model.UserRegisterModel;

@Component
public class LabRecordService 
{
	@Autowired
	private SessionBuilder sessBuilder;
	
	public String save(PatientDocument patd) 
	{
		Session sess = null;
		try {
			sess= sessBuilder.getSess();
			
			sess.save(patd);
			sess.beginTransaction().commit();
			return "Record Successfully Done.";
		}catch(Exception ex) {
			ex.printStackTrace();
			return "Record Save Failed , " + ex.getMessage();
		}finally {
			sess.close();
		}
	}

	public List<PatientDocument> getPatientLabRecords(Patient patient) 
	{
		Session sess= sessBuilder.getSess();
		
		Query<PatientDocument> qu = sess.createQuery("from PatientDocument where patient=?1");
		qu.setParameter(1, patient);
			
		List<PatientDocument> list = qu.list();
		
		sess.close();
		return list;
	}

	public void approve(Integer id) {
		Session sess= sessBuilder.getSess();
		PatientDocument patd= sess.get(PatientDocument.class, id);
		if(patd!=null) {
			patd.setIsApproved(true);
			sess.update(patd);
			sess.beginTransaction().commit();
		}
	}
}
