package com.davv.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.davv.controller.LabController;
import com.davv.dao.SessionBuilder;
import com.davv.entities.Doctor;
import com.davv.entities.Laboratory;
import com.davv.entities.Patient;
import com.davv.entities.User;
import com.davv.model.UserRegisterModel;

@Component
public class UserService 
{
	@Autowired
	private SessionBuilder sessBuilder;
	
	public String saveUser(UserRegisterModel model) 
	{
		Session sess = null;
		try {
			sess= sessBuilder.getSess();
			
			if(model.getRole().equals("Patient")) {
				Patient p = new Patient(model);
				sess.save(p);
			}else if(model.getRole().equals("Doctor")) {
				Doctor d = new Doctor(model);
				sess.save(d);
			}else {
				Laboratory l = new Laboratory(model);
				sess.save(l);
			}
			sess.beginTransaction().commit();
			return "User Registeration Successfully Done.";
		}catch(Exception ex) {
			ex.printStackTrace();
			return "User Registeration Failed , " + ex.getMessage();
		}finally {
			sess.close();
		}
	}

	public User getUser(String mobile, String pwd) 
	{
		Session sess= sessBuilder.getSess();
		
		Query<User> qu = sess.createQuery("from User where mobile=?1 and password=?2");
		qu.setParameter(1, mobile);
		qu.setParameter(2, pwd);
		
		User user = qu.uniqueResult();
		
		sess.close();
		return user;
	}

	public void update(User user) {
		Session sess= sessBuilder.getSess();
		sess.update(user);
		sess.beginTransaction().commit();
		sess.close();
		
	}
	
	public List<Doctor> listDoctors() {
		Session sess= sessBuilder.getSess();
		
		Query<Doctor> qu = sess.createQuery("from Doctor");
			
		List<Doctor> list = qu.list();
		
		sess.close();
		return list;
	}

	public Doctor getDoctorById(Integer id) {
		Session sess= sessBuilder.getSess();
		
		Doctor doctor = sess.get(Doctor.class, id);
		
		sess.close();
		return doctor;
	}

	public List<Laboratory> listLab() {
		Session sess= sessBuilder.getSess();
		
		Query<Laboratory> qu = sess.createQuery("from Laboratory");
			
		List<Laboratory> list = qu.list();
		
		sess.close();
		return list;
	}
	public Laboratory getLabById(Integer id) {
		// TODO Auto-generated method stub
		Session sess= sessBuilder.getSess();
		Laboratory lab=sess.get(Laboratory.class,id);
		sess.close();
		return lab;
	}
	
	public List<Patient> listPatient() {
		Session sess= sessBuilder.getSess();
		
		Query<Patient> qu = sess.createQuery("from Patient");
			
		List<Patient> list = qu.list();
		
		sess.close();
		return list;
	}
	
	public Patient getPatientById(Integer id) {
		Session sess= sessBuilder.getSess();
		
		Patient patient = sess.get(Patient.class, id);
		
		sess.close();
		return patient;
	}

}
