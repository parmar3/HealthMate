package com.davv.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.davv.entities.User;

@Component
public class FileUploadService 
{
	private final String BASE_PATH = "D:/4thsemproject/Uploadedfiles";

	
	public String uploadMedicalRecord(byte [] data,String name) throws IOException 
	{
		String fileName = UUID.randomUUID().toString() + name.substring(name.indexOf("."));
		String dir = "/medi_record/"+fileName;
		
		File fileOb = new File(BASE_PATH, dir);
		FileOutputStream fos = new FileOutputStream(fileOb);
		fos.write(data);
		fos.close();
		
		return dir;
	}
	
	public String uploadTestRecord(byte [] data,String name) throws IOException 
	{
		String fileName = UUID.randomUUID().toString() + name.substring(name.indexOf("."));
		String dir = "/test_record/"+fileName;
		
		File fileOb = new File(BASE_PATH, dir);
		FileOutputStream fos = new FileOutputStream(fileOb);
		fos.write(data);
		fos.close();
		
		return dir;
	}
}
