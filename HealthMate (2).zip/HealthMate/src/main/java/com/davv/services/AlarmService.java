package com.davv.services;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.davv.dao.SessionBuilder;
import com.davv.entities.SetAlarm;

@Service
public class AlarmService {

    @Autowired
    private JavaMailSender mailSender;

    // RUNS EVERY MINUTE
    @Scheduled(cron = "0 * * * * *")
    public void checkAlarms() {

        Session session = SessionBuilder.getFactory().openSession();
        Transaction tx = session.beginTransaction();

        try {

        	LocalDate todayDate = LocalDate.now();

        	String today = todayDate.toString();
            String currentTime = LocalTime.now()
                    .format(DateTimeFormatter.ofPattern("HH:mm"));

            List<SetAlarm> alarms = session.createQuery(
            	    "from SetAlarm where startDate <= :today and endDate >= :today and time = :time",
            	    SetAlarm.class)
            	    .setParameter("today", today)
            	    .setParameter("time", currentTime)
            	    .list();

            for (SetAlarm alarm : alarms) {

                // prevent duplicate mail same day
                if (alarm.getLastSentDate() != null
                        && alarm.getLastSentDate().equals(todayDate)) {
                    continue;
                }

                sendEmail(alarm);

                alarm.setLastSentDate(todayDate);
                session.merge(alarm);
            }

            tx.commit();

        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            session.close();
        }
    }

    private void sendEmail(SetAlarm alarm) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(alarm.getPatient().getEmail());
        message.setSubject("HealthMate Medicine Reminder");

        message.setText(
                "Hello " + alarm.getPatient().getName() + ",\n\n"
                        + "This is your medicine reminder.\n\n"
                        + "Medicine Details: " + alarm.getDescription() + "\n"
                        + "Time: " + alarm.getTime() + "\n\n"
                        + "Take care.\n"
                        + "HealthMate");

        mailSender.send(message);

        System.out.println("Reminder sent to: "
                + alarm.getPatient().getEmail());
    }
}