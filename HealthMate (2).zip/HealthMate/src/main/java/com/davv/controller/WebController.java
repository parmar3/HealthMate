package com.davv.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.davv.entities.User;
import com.davv.model.UserRegisterModel;
import com.davv.services.UserService;

@Controller
public class WebController 
{
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/home",method = RequestMethod.GET)
	public String home() {
		return "home";
	}
	
	@RequestMapping(value = "/about",method = RequestMethod.GET)
	public String about() {
		return "about";
	}
	
	@RequestMapping(value = "/login",method = RequestMethod.GET)
	public String login() {
		return "login";
	}
	
	@RequestMapping(value = "/login",method = RequestMethod.POST)
	public String loginUser(@RequestParam(value = "mobile") String mobile, 
			@RequestParam(value="pwd")String pwd, ModelMap map, HttpSession session) 
	{
		User user = userService.getUser(mobile,pwd);
		if(user==null) {
			map.addAttribute("msg", "Invalid Mobile or Password.");
			return "msg";
		}else {
			
			session.setAttribute("user", user);
			
			String role = user.getRole();
			return "redirect:/"+role+"/home";
		}
		}
	@RequestMapping(value = "/register",method = RequestMethod.GET)
	public String register() {
		return "register";
	}
	@RequestMapping(value = "/dashboard",method = RequestMethod.GET)
	public String dashboard() {
		return "dashboard";
	}
	
	
	@RequestMapping(value = "/register" , method = RequestMethod.POST)
	public String register(UserRegisterModel model,ModelMap map) 
	{
		String result = userService.saveUser(model);
		map.addAttribute("msg", result);
		return "msg";
	}
}
