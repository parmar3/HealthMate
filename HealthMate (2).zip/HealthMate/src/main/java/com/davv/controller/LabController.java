package com.davv.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/laboratory")
public class LabController 
{
	@RequestMapping(value = "/home")
	public String home() 
	{
		return "laboratory/home";
	}
	
	@RequestMapping(value = "/upload" ,method=RequestMethod.GET)
	public String upload() 
	{
		return "laboratory/upload";
	}

	@RequestMapping(value = "/viewpres" ,method=RequestMethod.GET)
	public String viewpres() 
	{
		return "laboratory/viewpres";
	}
}
