/*package com.davv.controller;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.davv.entities.Doctor;
import com.davv.entities.MedicalRecord;
import com.davv.entities.Patient;
import com.davv.entities.User;
import com.davv.model.MedicalRecordModel;
import com.davv.services.FileUploadService;
import com.davv.services.MedicalRecordService;
import com.davv.services.UserService;

@Controller
@RequestMapping(value = "/doctor")
public class DoctorController 
{
	
	@Autowired
	private UserService userService;
	@Autowired
	private FileUploadService uploadService;
	
	@Autowired
	private MedicalRecordService mediRecService;
	
	@RequestMapping(value = "/home")
	public String home() 
	{
		return "doctor/home";
	}
	@RequestMapping(value = "/upload" ,method=RequestMethod.GET)
	public String upload() 
	{
		return "doctor/upload";
	}

	@RequestMapping(value = "/viewpres" ,method=RequestMethod.GET)
	public String viewpres() 
	{
		return "doctor/viewpres";
	}
	
	@RequestMapping(value = "/upload",method = RequestMethod.POST)
	public String saveMedicalRecords(@RequestParam("file") MultipartFile file,
										MedicalRecordModel model, HttpSession session, 
										ModelMap map) 
	{
		User user = (User) session.getAttribute("user");
		Doctor doctor = (Doctor) user;
		try {
			byte fileData[] = file.getBytes();
			//System.out.println(file.getOriginalFilename() + " : " + fileData.length);
			String filePath = uploadService.uploadMedicalRecord(fileData, file.getOriginalFilename());
			
			Patient patient = userService.getPatientById(model.getPatient());
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(model.getDate());
			
			MedicalRecord rec = new MedicalRecord();
			rec.setDate(date.toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate());
			rec.setDescription(model.getDesc());
			rec.setIsApproved(false);
			rec.setPath(filePath);
			rec.setDoctor(doctor);
			rec.setUploadby(model.getUploadby());
			rec.setPatient(patient);
			
			mediRecService.save(rec);
			
			return "redirect:/patient/uploadpres";
		} catch (Exception e) {
			map.addAttribute("msg", e.getMessage());
			return "msg";
		}
	}

	
}*/

package com.davv.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.davv.entities.Doctor;
import com.davv.entities.MedicalRecord;
import com.davv.entities.Patient;
import com.davv.entities.User;
import com.davv.model.MedicalRecordModel;
import com.davv.services.FileUploadService;
import com.davv.services.MedicalRecordService;
import com.davv.services.UserService;

@Controller
@RequestMapping(value = "/doctor")
public class DoctorController 
{

    @Autowired
    private UserService userService;

    @Autowired
    private FileUploadService uploadService;

    @Autowired
    private MedicalRecordService mediRecService;

    @RequestMapping(value = "/home")
    public String home() 
    {
        return "doctor/home";
    }

    @RequestMapping(value = "/upload", method = RequestMethod.GET)
    public String upload(ModelMap map) 
    {
        List<Patient> plist = userService.listPatient();

        map.addAttribute("plist", plist);

        return "doctor/upload";
    }

    @RequestMapping(value = "/viewpres", method = RequestMethod.GET)
    public String viewpres(ModelMap map, HttpSession session) 
    {
        User user = (User) session.getAttribute("user");

        Doctor doctor = (Doctor) user;

        List<MedicalRecord> reclist = mediRecService.getDoctorRecords(doctor);

        map.addAttribute("reclist", reclist);

        return "doctor/viewpres";
    }

    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public String saveMedicalRecords(@RequestParam("file") MultipartFile file,
                                     MedicalRecordModel model,
                                     HttpSession session,
                                     ModelMap map) 
    {

        User user = (User) session.getAttribute("user");

        Doctor doctor = (Doctor) user;

        try 
        {

            byte fileData[] = file.getBytes();

            String filePath = uploadService.uploadMedicalRecord(
                    fileData,
                    file.getOriginalFilename());

            Patient patient = userService.getPatientById(model.getPatient());

            LocalDate date = LocalDate.parse(model.getDate());

            MedicalRecord rec = new MedicalRecord();

            rec.setDate(date);
            rec.setDescription(model.getDesc());
            rec.setIsApproved(false);
            rec.setPath(filePath);
            rec.setDoctor(doctor);
            rec.setUploadby(model.getUploadby());
            rec.setPatient(patient);

            mediRecService.save(rec);

            return "redirect:/doctor/viewpres";

        } 
        catch (Exception e) 
        {

            map.addAttribute("msg", e.getMessage());

            return "msg";
        }
    }
}

