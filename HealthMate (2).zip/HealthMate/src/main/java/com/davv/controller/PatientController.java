package com.davv.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.davv.dao.SessionBuilder;
import com.davv.entities.Doctor;
import com.davv.entities.Laboratory;
import com.davv.entities.MedicalRecord;
import com.davv.entities.Patient;
import com.davv.entities.PatientDocument;
import com.davv.entities.SetAlarm;
import com.davv.entities.User;
import com.davv.model.LabRecordModel;
import com.davv.model.MedicalRecordModel;
import com.davv.services.FileUploadService;
import com.davv.services.LabRecordService;
import com.davv.services.MedicalRecordService;

import com.davv.services.UserService;


@Controller
@RequestMapping(value = "/patient")
public class PatientController 
{
	@Autowired
	private UserService userService;
	@Autowired
	private FileUploadService uploadService;
	@Autowired
	private MedicalRecordService mediRecService;
	@Autowired
	private LabRecordService labsev;

	@RequestMapping(value = "/home")
	public String home() 
	{
		return "patient/home";
	}
	@RequestMapping(value = "/setAlarm" ,method=RequestMethod.GET)
	public String setAlarm() 
	{
		return "patient/setAlarm";
	}
	@RequestMapping(value = "/upload" ,method=RequestMethod.GET)
	public String upload() 
	{
		return "patient/upload";
	}
	
	@RequestMapping(value = "/view" ,method=RequestMethod.GET)
	public String view() 
	{
		return "patient/view";
	}

	@RequestMapping(value = "/approve/{id}",method = RequestMethod.GET)
	public String approveRecord(@PathVariable(value = "id") Integer id) 
	{
		mediRecService.approve(id);
		return "redirect:/patient/records";
	}
	
	@RequestMapping(value = "/uploadpres",method = RequestMethod.GET)
	public String medicalRecords(ModelMap map, HttpSession session) 
	{
		
		List<Doctor> dlist = userService.listDoctors();
		
		
		map.addAttribute("dlist", dlist);
		return "patient/uploadpres";
	}
	
	@RequestMapping(value = "/viewpres",method = RequestMethod.GET)
	public String medicalRecord(ModelMap map, HttpSession session) 
	{
		User user = (User) session.getAttribute("user");
		Patient patient = (Patient) user;
		
		List<Doctor> dlist = userService.listDoctors();
		List<MedicalRecord> reclist = mediRecService.getPatientRecords(patient);
		
		map.addAttribute("dlist", dlist);
		map.addAttribute("reclist", reclist);
		return "patient/viewpres";
	}
	
	@RequestMapping(value = "/uploadpres",method = RequestMethod.POST)
	public String saveMedicalRecords(@RequestParam("file") MultipartFile file,
										MedicalRecordModel model, HttpSession session, 
										ModelMap map) 
	{
		User user = (User) session.getAttribute("user");
		Patient patient = (Patient) user;
		try {
			byte fileData[] = file.getBytes();
			//System.out.println(file.getOriginalFilename() + " : " + fileData.length);
			String filePath = uploadService.uploadMedicalRecord(fileData, file.getOriginalFilename());
			
			Doctor doctor = userService.getDoctorById(model.getDoctor());
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(model.getDate());
			
			MedicalRecord rec = new MedicalRecord();
			rec.setDate(date.toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate());
			rec.setDescription(model.getDesc());
			rec.setIsApproved(true);
			rec.setPath(filePath);
			rec.setPatient(patient);
			rec.setUploadby(model.getUploadby());
			rec.setDoctor(doctor);
			
			mediRecService.save(rec);
			
			return "redirect:/patient/uploadpres";
		} catch (Exception e) {
			map.addAttribute("msg", e.getMessage());
			return "msg";
		}
	}

	
	@RequestMapping(value = "/uploadtest",method = RequestMethod.GET)
	public String testRecords(ModelMap map, HttpSession session) 
	{
		
		List<Laboratory> dlist = userService.listLab();
		
		
		map.addAttribute("dlist", dlist);
		return "patient/uploadtest";
	}
	
	@RequestMapping(value = "/viewtest",method = RequestMethod.GET)
	public String testRecord(ModelMap map, HttpSession session) 
	{
		User user = (User) session.getAttribute("user");
		Patient patient = (Patient) user;
		
		List<Laboratory> reclist = userService.listLab();
		List<PatientDocument> reclist1 = labsev.getPatientLabRecords(patient);
		
		map.addAttribute("list", reclist);
		map.addAttribute("reclist", reclist1);
		return "patient/viewtest";
	}
	
	@RequestMapping(value = "/uploadtest",method = RequestMethod.POST)
	public String saveTestRecords(@RequestParam("file") MultipartFile file,
										LabRecordModel model, HttpSession session, 
										ModelMap map) 
	{
		User user = (User) session.getAttribute("user");
		Patient patient = (Patient) user;
		try {
			byte fileData[] = file.getBytes();
			//System.out.println(file.getOriginalFilename() + " : " + fileData.length);
			String filePath = uploadService.uploadTestRecord(fileData, file.getOriginalFilename());
			
			Laboratory lab = userService.getLabById(model.getLab());
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(model.getDate());
			
			PatientDocument patd= new PatientDocument();
			patd.setDate(date.toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate());
			patd.setCategory(model.getCategory());
			patd.setIsApproved(true);
			patd.setPath(filePath);
			patd.setPatient(patient);
			patd.setUploadby(model.getUploadby());
			
			
			labsev.save(patd);
			
			return "redirect:/patient/uploadtest";
		} catch (Exception e) {
			map.addAttribute("msg", e.getMessage());
			return "msg";
		}
	}

	@PostMapping(value = "/saveAlarm")
    public String saveAlarm(@ModelAttribute SetAlarm alarm,
                             HttpSession httpSession) {

        Patient patient = (Patient) httpSession.getAttribute("user");

        alarm.setPatient(patient);

        Session session = SessionBuilder.getFactory().openSession();
        Transaction tx = session.beginTransaction();

        try {

            session.persist(alarm);

            tx.commit();

        } catch (Exception e) {
            tx.rollback();
            e.printStackTrace();

        } finally {
            session.close();
        }

        return "redirect:/patient/home";
	
	}
}
