package com.davv.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.davv.entities.User;
import com.davv.services.UserService;

@Controller
@RequestMapping(value = "/user")
public class UserController 
{
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) 
	{
		session.invalidate();
		return "redirect:/login";
	}
	
	@RequestMapping(value = "/changepwd",method = RequestMethod.GET)
	public String changePwd() 
	{
		return "user/changepwd";
	}
	@RequestMapping(value = "/changepwd",method = RequestMethod.POST)
	public String updatePwd(@RequestParam(value = "oldpwd") String oldpwd , 
					@RequestParam(value = "newpwd") String newpwd,HttpSession session,ModelMap map) 
	{
		User user = (User)session.getAttribute("user");
		if(user.getPassword().equals(oldpwd)) {
			user.setPassword(newpwd);
			userService.update(user);
			return "redirect:/login";
		}else {
			map.addAttribute("msg", "Old Password Not Match.");
			return "msg";
		}
	}
}
