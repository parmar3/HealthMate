package com.davv.model;

import java.time.LocalDate;

public class LabRecordModel 
{
	private String uploadby;
	private String date;
	
	private Integer lab;
	public Integer getLab() {
		return lab;
	}
	public void setLab(Integer lab) {
		this.lab = lab;
	}
	private String category;
	public String getUploadby() {
		return uploadby;
	}
	public void setUploadby(String uploadby) {
		this.uploadby = uploadby;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	public String getCategory() {
		// TODO Auto-generated method stub
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "LabRecordModel [uploadby=" + uploadby + ", date=" + date + ", lab=" + lab + ", category=" + category
				+ "]";
	}
	
	
	
	
	
}
