package com.davv.model;

import java.time.LocalDate;

public class MedicalRecordModel 
{
	private String uploadby;
	private String date;
	private Integer doctor;
	private String desc;
	public String getUploadby() {
		return uploadby;
	}
	public void setUploadby(String uploadby) {
		this.uploadby = uploadby;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getDoctor() {
		return doctor;
	}
	public void setDoctor(Integer doctor) {
		this.doctor = doctor;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	@Override
	public String toString() {
		return "MedicalRecordModel [uploadby=" + uploadby + ", date=" + date + ", doctor=" + doctor + ", desc=" + desc
				+ "]";
	}
	public Integer getPatient() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
