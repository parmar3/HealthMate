package com.davv.model;

public class UserRegisterModel 
{
	private String name;
	private String email;
	private String mobile;
	private String pwd;
	private String regno;
	private String cate;
	private String role;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getCate() {
		return cate;
	}
	public void setCate(String cate) {
		this.cate = cate;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "UserRegisterModel [name=" + name + ", email=" + email + ", mobile=" + mobile + ", pwd=" + pwd
				+ ", regno=" + regno + ", cate=" + cate + ", role=" + role + "]";
	}
	
	
}
