package com.davv.entities;

import com.davv.model.UserRegisterModel;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "labs")
public class Laboratory extends User
{
	@Column(name = "category" ,nullable = false)
	private String category;
	@Column(name = "regno" ,nullable = false)
	private String regno;
	
	public Laboratory() {}

	public Laboratory(String name, String address, String mobile, String password, String email, String role,
			boolean status, String category, String regno) {
		super(name, address, mobile, password, email, role, status);
		this.category = category;
		this.regno = regno;
	}
	
	public Laboratory(UserRegisterModel model) 
	{
		setName(model.getName());
		setMobile(model.getMobile());
		setPassword(model.getPwd());
		setEmail(model.getEmail());
		setRole(model.getRole().toLowerCase());
		setStatus(true);
		this.regno = model.getRegno();
		this.category = model.getCate();
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getRegno() {
		return regno;
	}

	public void setRegno(String regno) {
		this.regno = regno;
	}
	
	
}
