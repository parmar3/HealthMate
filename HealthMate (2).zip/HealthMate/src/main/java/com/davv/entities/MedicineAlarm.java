package com.davv.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "medicine_alarms")
public class MedicineAlarm {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String medicineName;
    private String patientEmail;
    private String phoneNumber;
    
    @Temporal(TemporalType.DATE)
    private Date startDate;
    
    @Temporal(TemporalType.DATE)
    private Date endDate;
    
    private String alarmTime; // Format: "HH:mm"

	public String getPatientEmail() {
		
		return null;
	}

	public String getMedicineName() {
		// TODO Auto-generated method stub
		return null;
	}
    
    // Getters and Setters
}