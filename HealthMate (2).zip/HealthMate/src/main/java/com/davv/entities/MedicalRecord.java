package com.davv.entities;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name ="records")
public class MedicalRecord {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="rec_id")
	private Integer recId;
	
	@Column(name="date", nullable=false)
	private LocalDate date;
	
	@Column(name="path", nullable=false)
	private String path;
		
	@Column(name="upload_by", nullable= false)
	private String uploadby;
	
	@Column(name="is_approved", nullable= false)
	private Boolean isApproved; 

	@ManyToOne
	@JoinColumn(name="patient")
	private Patient patient;
	
	@ManyToOne
	@JoinColumn(name="doctor",nullable = true)
	private Doctor doctor;
	
	@Column(name="description", nullable=false)
	private String description;

	public Integer getRecId() {
		return recId;
	}

	public void setRecId(Integer recId) {
		this.recId = recId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getUploadby() {
		return uploadby;
	}

	public void setUploadby(String uploadby) {
		this.uploadby = uploadby;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
}