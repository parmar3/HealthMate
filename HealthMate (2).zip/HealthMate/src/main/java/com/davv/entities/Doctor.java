package com.davv.entities;

import java.time.LocalDate;

import com.davv.model.UserRegisterModel;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "doctors")
public class Doctor extends User
{
	@Column(name = "spec" ,nullable = true)
	private String spec;
	
	@Column(name = "hospital" ,nullable = true)
	private String hospital;
	
	@Column(name = "regno" ,nullable = false)
	private String regno;
	
	@Column(name = "gender" ,nullable = true)
	private String gender;
		
	@Column(name = "dob" ,nullable = true)
	private LocalDate dob;
	
	public Doctor() {}

	public Doctor(String name, String address, String mobile, String password, String email, String role,
			boolean status, String spec, String hospital, String regno, String gender, LocalDate dob) {
		super(name, address, mobile, password, email, role, status);
		this.spec = spec;
		this.hospital = hospital;
		this.regno = regno;
		this.gender = gender;
		this.dob = dob;
	}
	
	public Doctor(UserRegisterModel model) 
	{
		setName(model.getName());
		setMobile(model.getMobile());
		setPassword(model.getPwd());
		setEmail(model.getEmail());
		setRole(model.getRole().toLowerCase());
		setStatus(true);
		this.regno = model.getRegno();
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getHospital() {
		return hospital;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

	public String getRegno() {
		return regno;
	}

	public void setRegno(String regno) {
		this.regno = regno;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	
	
}
