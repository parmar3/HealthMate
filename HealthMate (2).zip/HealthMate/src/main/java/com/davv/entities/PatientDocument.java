package com.davv.entities;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name ="document")
public class PatientDocument 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="doc_id")
	private Integer docId;
	
	@Column(name="title", nullable=false)
	private String title;
	
	@Column(name="date", nullable=false)
	private LocalDate date;
	
	@Column(name="path", nullable=false)
	private String path;
	
	@Column(name="category", nullable=false)
	private String category;
	
	@Column(name="upload_by", nullable= false)
	private String uploadby;
	
	@Column(name="is_approved", nullable= false)
	private Boolean isApproved; 

	@ManyToOne
	@JoinColumn(name="patient")
	private Patient patient;
	
	@ManyToOne
	@JoinColumn(name="lab",nullable = true)
	private Laboratory lab;

	public Integer getDocId() {
		return docId;
	}

	public void setDocId(Integer docId) {
		this.docId = docId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getUploadby() {
		return uploadby;
	}

	public void setUploadby(String uploadby) {
		this.uploadby = uploadby;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Laboratory getLab() {
		return lab;
	}

	public void setLab(Laboratory lab) {
		this.lab = lab;
	}

	

	
}

