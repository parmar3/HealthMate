package com.davv.entities;

import java.time.LocalDate;

import com.davv.model.UserRegisterModel;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "patients")
public class Patient extends User
{
	@Column(name = "gender" ,nullable = true)
	private String gender;
		
	@Column(name = "dob" ,nullable = true)
	private LocalDate dob;
	
	public Patient() {}

	public Patient(String name, String address, String mobile, String password, String email,String role, boolean status, String gender,
			 LocalDate dob) {
		super(name, address,mobile, password, email , role, status);
		this.gender = gender;
		this.dob = dob;
	}

	public Patient(UserRegisterModel model) 
	{
		setName(model.getName());
		setMobile(model.getMobile());
		setPassword(model.getPwd());
		setEmail(model.getEmail());
		setRole(model.getRole().toLowerCase());
		setStatus(true);
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
}
