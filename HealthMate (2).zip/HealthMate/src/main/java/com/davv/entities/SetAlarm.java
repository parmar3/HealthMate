/*package com.davv.entities;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name ="alarm")
public class SetAlarm {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="alarm_id")
	private Integer alarmId;

	@ManyToOne
	@JoinColumn(name="patient", nullable=false)
	private Patient patient;
	
	@Column(name="start_date", nullable=false)
	private LocalDate startDate;
	
	@Column(name="end_date", nullable=false)
	private LocalDate endDate;

	@Column(name="time", nullable=false)
	private String time;
	
	@Column(name="description", nullable=false)
	private String description;

	public Integer getAlarmId() {
		return alarmId;
	}

	public void setAlarmId(Integer alarmId) {
		this.alarmId = alarmId;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public SetAlarm() {}
	public SetAlarm(Integer alarmId, Patient patient, LocalDate startDate, LocalDate endDate, String time,
			String description) {
		super();
		this.alarmId = alarmId;
		this.patient = patient;
		this.startDate = startDate;
		this.endDate = endDate;
		this.time = time;
		this.description = description;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	

}*/

package com.davv.entities;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "alarm")
public class SetAlarm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "alarm_id")
    private Integer alarmId;

    @ManyToOne
    @JoinColumn(name = "patient", nullable = false)
    private Patient patient;

    @Column(name = "start_date", nullable = false)
    private String startDate;

    @Column(name = "end_date", nullable = false)
    private String endDate;

    @Column(name = "time", nullable = false)
    private String time;

    @Column(name = "description", nullable = false)
    private String description;

    // NEW COLUMN
    @Column(name = "last_sent_date")
    private LocalDate lastSentDate;

    public SetAlarm() {
    }

    public Integer getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(Integer alarmId) {
        this.alarmId = alarmId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getLastSentDate() {
        return lastSentDate;
    }

    public void setLastSentDate(LocalDate lastSentDate) {
        this.lastSentDate = lastSentDate;
    }
}



