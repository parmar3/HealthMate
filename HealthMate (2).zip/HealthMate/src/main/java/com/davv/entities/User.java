package com.davv.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
@Inheritance(strategy = InheritanceType.JOINED)
public class User 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "name" ,nullable = false)
	private String name;
	
	@Column(name = "address" ,nullable = true)
	private String address;
	
	@Column(name = "mobile" , unique = true , nullable = false)
	private String mobile;
	
	@Column(name = "password" ,nullable = false)
	private String password;
	
	@Column(name = "email" ,nullable = true)
	private String email;
	
	@Column(name = "role" ,nullable = false)
	private String role;
	
	@Column(name = "status" ,nullable = false)
	private boolean status;
	
	public User() {}

	public User(String name, String address,String mobile, String password, String email, String role, boolean status) {
		super();
		this.name = name;
		this.address = address;
		this.mobile = mobile;
		this.password = password;
		this.email = email;
		this.role = role;
		this.status = status;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
}
