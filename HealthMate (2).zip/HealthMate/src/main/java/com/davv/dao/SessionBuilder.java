/*package com.davv.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;

@Component
public class SessionBuilder 
{
	private SessionFactory sf;
	public SessionBuilder() {
		Configuration cfg = new Configuration().configure();
		sf = cfg.buildSessionFactory();
	}
	
	public Session getSess() {
		return sf.openSession();
	}
}
*/

package com.davv.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;

@Component
public class SessionBuilder {

    private static SessionFactory sf;

    public SessionBuilder() {
        Configuration cfg = new Configuration().configure();
        sf = cfg.buildSessionFactory();
    }

    public Session getSess() {
        return sf.openSession();
    }

    public static SessionFactory getFactory() {
        return sf;
    }
}