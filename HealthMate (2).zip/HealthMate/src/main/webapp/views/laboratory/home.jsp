<%@include file="../blocks/userheader.jsp" %>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">
      </div>
      
    </section>
  </main>
  
<%@include file="../blocks/footer.jsp" %>      