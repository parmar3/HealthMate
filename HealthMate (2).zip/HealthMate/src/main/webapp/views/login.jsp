<%@include file="blocks/header.jsp" %>

<main class="main">

    <!-- Page Title -->
    <div class="page-title">
      <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              
            </div>
          </div>
    </div><!-- End Page Title -->

    <!-- Contact Section -->
    <section id="contact" class="contact section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row g-5">
        
           <div class="col-lg-6">
            <div class="contact-form-card" data-aos="fade-up" data-aos-delay="200">
              <h2>User Login</h2>            
				<form action="<%=ctxPath%>/login" method="post">  
              <div class="row">
              	<div class="col-xl-6 col-lg-6">
              		<input type="text" placeholder="Mobile" name="mobile" class="form-control" required>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		<input type="password" placeholder="Password" name="pwd" class="form-control" required>
              	</div>
              </div>
               <div class="row mt-3">
              	<div class="col-xl-6 col-lg-6">
              		<button class="btn btn-primary">Login</button>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              	</div>
              	
              </div>
              </form>
            </div>
          </div>
          
          

  </main>


<%@include file="blocks/footer.jsp" %>