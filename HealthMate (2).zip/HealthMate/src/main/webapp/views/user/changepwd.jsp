<%@include file="../blocks/userheader.jsp" %>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">
      		 <h2>Change Password</h2>            

			 <form action="<%=ctxPath%>/user/changepwd" method="post">  
              <div class="row">
              	<div class="col-xl-6 col-lg-6">
              		<input type="password" placeholder="Old Password" name="oldpwd" class="form-control" required>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		<input type="password" placeholder="New Password" name="newpwd" class="form-control" required>
              	</div>
              </div>
              <div class="row mt-3">
              	<div class="col-xl-6 col-lg-6">
              		<button class="btn btn-primary">Change</button>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		
              	</div>
              </div>
              </form>
      </div>
      
    </section>
  </main>
  
<%@include file="../blocks/footer.jsp" %> 