  <footer id="footer" class="footer-16 footer position-relative">

    <div class="container">

      <div class="footer-main" data-aos="fade-up" data-aos-delay="100">
        <div class="row align-items-start">

          <div class="col-lg-5">
            <div class="brand-section">
              <a href="index.html" class="logo d-flex align-items-center mb-4">
                <span class="sitename">HealthMate</span>
              </a>
              <p class="brand-description">A supportive system for records and medicine alerts.</p>
            </div>
          </div>

          
    <div class="footer-bottom">
      <div class="container">
        <div class="bottom-content" data-aos="fade-up" data-aos-delay="300">
          <div class="row align-items-center">

            <div class="col-lg-6">
              <div class="copyright">
                <p>� <span class="sitename">HealthMate</span>. All rights reserved.</p>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="legal-links">
                <a href="#!">Privacy Policy</a>
                <a href="#!">Terms of Service</a>
                <a href="#!">Cookie Policy</a>
                
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#!" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<%=ctxPath%>/resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<%=ctxPath%>/resources/assets/vendor/php-email-form/validate.js"></script>
  <script src="<%=ctxPath%>/resources/assets/vendor/aos/aos.js"></script>
  <script src="<%=ctxPath%>/resources/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<%=ctxPath%>/resources/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<%=ctxPath%>/resources/assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="<%=ctxPath%>/resources/assets/js/main.js"></script>

</body>

</html>