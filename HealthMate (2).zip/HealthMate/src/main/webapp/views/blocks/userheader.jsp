<%@page import="com.davv.entities.User"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@taglib prefix="sp" uri="http://java.sun.com/jsp/jstl/core"%>
    
    
    
<%
	String ctxPath = "/HealthMate";
	User user = (User)session.getAttribute("user");
%>    
    
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Health Mate : <%=user.getRole().toUpperCase()%></title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<%=ctxPath%>/resources/assets/img/favicon.png" rel="icon">
  <link href="<%=ctxPath%>/resources/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<%=ctxPath%>/resources/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<%=ctxPath%>/resources/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<%=ctxPath%>/resources/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<%=ctxPath%>/resources/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<%=ctxPath%>/resources/assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<%=ctxPath%>/resources/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<%=ctxPath%>/resources/assets/css/main.css" rel="stylesheet">
</head>

<body class="index-page">

 <header id="header" class="header fixed-top">

    <div class="topbar d-flex align-items-center dark-background">
      <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
          <i class="bi bi-envelope d-flex align-items-center"><a
              href="mailto:contact@example.com">contact@healthmate.com</a></i>
          <i class="bi bi-phone d-flex align-items-center ms-4"><span>7389427878</span></i>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
          <a href="#!" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="#!" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>
    </div><!-- End Top Bar -->


    <div class="branding d-flex align-items-cente">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="<%=ctxPath%>/<%=user.getRole()%>/home" class="logo d-flex align-items-center">
          <h1 class="sitename">Health Mate - Welcome <%=user.getName()%> </h1>
        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="<%=ctxPath%>/<%=user.getRole()%>/home">Home</a></li>
            <li class="dropdown"><a href="#"><span>Settings</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              
               <li><a href="<%=ctxPath%>/user/changepwd">Change Password</a></li>
               <li><a href="<%=ctxPath%>/user/logout">Logout</a></li>              
            </ul>
            </li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

      </div>

    </div>

  </header>