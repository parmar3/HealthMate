<%@include file="../blocks/userheader.jsp" %>

  <main class="main">
	<br><br><br><br><br>
	<h1>Lab  Reports</h1>
   
   	<div class="container">
   	
    <table class="table mt-3">
    	<thead>
    		<tr>
    		 <th>S. No.</th>
    		 <th>Date</th>
    		 <th>Description</th>
    		
    		 <th>Approve Status</th>
    		 <th>View</th>
    		</tr>
    	</thead>
    	<tbody>
    		<sp:set var="i" value="1"/>
    		<sp:forEach var="rec" items="${reclist}">
    			<tr>
    				<td>${i}</td>
    				<td> ${rec.date} </td>
    				<td> ${rec.description} </td>
    				
    				<td>
    					<sp:if test="${rec.isApproved}"> <b>Approved</b> </sp:if>
    					<sp:if test="${!rec.isApproved}"> 
    						<a href="<%=ctxPath%>/patient/approve/${rec.recId}"> <b>Click To Approve </b></a>
    					</sp:if>
    				</td>
    				<td>
    					<a href="<%=ctxPath%>/files${rec.path}" target="_blank"> <b>View</b> </a>
    				</td>
    			</tr>
    			<sp:set var="i" value="${i+1}"/>
    		</sp:forEach>
    	</tbody>
    </table>
  </main>
  
<%@include file="../blocks/footer.jsp" %>      