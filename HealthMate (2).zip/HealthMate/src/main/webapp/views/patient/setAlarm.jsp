<%@include file="../blocks/userheader.jsp" %>
<style>
    .form-container {
        max-width: 500px;
        margin: 50px auto;
        padding: 30px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .form-group { margin-bottom: 15px; }
    label { display: block; margin-bottom: 5px; font-weight: bold; }
    input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
    .btn-submit { 
        width: 100%; padding: 12px; background: #1a73e8; color: white; 
        border: none; border-radius: 5px; cursor: pointer; font-size: 1rem;
    }
</style>
<br>
<br>
<br>
<div class="form-container">

    <h2>Schedule Medicine</h2>
<form action="<%= request.getContextPath() %>/patient/saveAlarm" method="POST">        <div class="form-group">
            <label>Medicine Name</label>
            <input type="text" name="description" required>
        </div>
        <div class="form-group">
            <label>Start Date</label>
            <input type="date" name="startDate" required>
        </div>
        <div class="form-group">
            <label>End Date</label>
            <input type="date" name="endDate" required>
        </div>
        <div class="form-group">
            <label>Time to take</label>
            <input type="time" name="time" required>
        </div>
        <button type="submit" class="btn-submit">Set Reminder</button>
    </form>
</div>