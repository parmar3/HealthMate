<%@include file="blocks/header.jsp" %>

<main class="main">

    <!-- Page Title -->
    <div class="page-title">
      <div class="row d-flex justify-content-center text-center">
            <div class="col-lg-8">
              
            </div>
          </div>
    </div><!-- End Page Title -->

    <!-- Contact Section -->
    <section id="contact" class="contact section">


          
          <div class="col-lg-6">
            <div class="contact-form-card" data-aos="fade-up" data-aos-delay="200">
              <h2>User Registeration</h2>    
              
              <form action="<%=ctxPath%>/register" method="post">       

				<div class="row mt-3">
              	<div class="col-xl-6 col-lg-6">
              		<select class="form-control" name="role" onchange="handleType(this.value)"  required>
              			<option value=''>Choose User Type</option>
              			<option>Patient</option>
              			<option>Doctor</option>
              			<option>Laboratory</option>
              		</select>
              	</div>
              	</div>	

				<div class="row">
              	<div class="col-xl-6 col-lg-6">
              		<input type="text" placeholder="Name*" name="name" class="form-control" required>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		<input type="email" placeholder="Email" name="email" class="form-control">
              	</div>
              </div>
               <div class="row mt-3">
              	<div class="col-xl-6 col-lg-6">
              		<input type="text" placeholder="Mobile*" name="mobile" class="form-control" required>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		<input type="password" placeholder="Password*" name="pwd" class="form-control" required>
              	</div>
              </div>
              
              <div class="row mt-3">
              	<div class="col-xl-6 col-lg-6">
              		<input type="text" style="display:none" id="regbox" name="regno" 
              		placeholder="Registeration Number" class="form-control">
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		<select class="form-control" id="catebox" style="display:none" name="cate">
              			<option value=''>Choose Category</option>
              			<option>Pathology</option>
              			<option>Radiology</option>
              			<option>Hybrid</option>
              		</select>
              	</div>              	
              </div>
              
              <div class="row mt-3">
              	<div class="col-xl-6 col-lg-6">
              		<button type="submit" class="btn btn-primary">Register</button>
              	</div>
              	<div class="col-xl-6 col-lg-6">
              		
              	</div>
              </div>
              </form> 
            </div>
          </div>
          
       
    </section><!-- /Contact Section -->

	<script>
			function handleType(type) {
				if(type=='') return;
				
				const regbox = document.getElementById('regbox');
				const catebox = document.getElementById('catebox');
				
				switch(type){
					case 'Patient' :  regbox.style.display = "none";  catebox.style.display = "none"; 
									  regbox.removeAttribute('required');  catebox.removeAttribute('required');
									break; 
					case 'Doctor' : regbox.style.display = "block";  catebox.style.display = "none";  
									regbox.setAttribute('required',true);catebox.removeAttribute('required');
									break; 
					case 'Laboratory' : regbox.style.display = "block";  catebox.style.display = "block";  
									regbox.setAttribute('required',true);catebox.setAttribute('required',true);
									break; 
				}				
			}
		
	</script>


  </main>


<%@include file="blocks/footer.jsp" %>