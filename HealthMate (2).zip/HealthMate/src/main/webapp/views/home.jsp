<%@include file="blocks/header.jsp" %>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="hero-content">
              <div class="trust-badges mb-4" data-aos="fade-right" data-aos-delay="200">
               
              </div>

              <h1 data-aos="fade-right" data-aos-delay="300">
               <span class="highlight">HealthMate</span> A supportive system for records and medicine alerts
              </h1>

              <p class="hero-description" data-aos="fade-right" data-aos-delay="400">
               HealthMate is a comprehensive electronic health record (EHR) and medicine management system. Securely store and access your complete medical history, Lab results, and prescriptions. Our integrated medicine reminder system ensures you never miss a dose, sending timely alerts. 
              </p>

             

              <div class="hero-actions" data-aos="fade-right" data-aos-delay="600">
                <a href="<%=ctxPath %>/register" class="btn btn-primary">Register Here</a>
              </div>

              
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hero-visual" data-aos="fade-left" data-aos-delay="400">
              <div class="main-image">
                <img src="<%=ctxPath%>/resources/assets/img/health/staff-10.webp" alt="Modern Healthcare Facility" class="img-fluid">
                
                 
                </div>
              </div>
              <div class="background-elements">
                <div class="element element-1"></div>
                <div class="element element-2"></div>
                <div class="element element-3"></div>
              </div>
            </div>
          </div>
        </div>

    

    </section><!-- /Hero Section -->

    <!-- Home About Section -->
    <section id="home-about" class="home-about section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row align-items-center">
          <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade-right" data-aos-delay="200">
            <div class="about-content">
              <h2 class="section-heading">What is unified health record system?</h2>
              <p class="lead-text">A Unified Health Record (UHR) system is a centralized digital platform that aggregates fragmented medical data from various healthcare providers into a single, comprehensive patient profile. Instead of having records scattered across different clinics or hospitals, a UHR creates a "one-stop" dashboard for both patients and clinicians.</p>

  
            </div>
          </div>

          <div class="col-lg-6" data-aos="fade-left" data-aos-delay="300">
            <div class="about-visual">
              <div class="main-image">
                <img src="<%=ctxPath%>/resources/assets/img/health/facilities-9.webp" alt="Modern medical facility" class="img-fluid">
              </div>
              <div class="floating-card">
                <div class="card-content">
                  <div class="icon">
                    <i class="bi bi-heart-pulse"></i>
                  </div>
                  <div class="card-text">
                    <h4>24/7 Emergency Care</h4>
                    <p>Always here when you need us most</p>
                  </div>
                </div>
              </div>
              
              </div>
            </div>
          </div>
        </div>


  
    <!-- Featured Services Section -->
    <section id="featured-services" class="featured-services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Featured Services</h2>
        <p>Our integrated platform connects patients, doctors, and laboratories to ensure a seamless flow of health information for better care coordination.</p>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row g-0">

          <div class="col-lg-8" data-aos="fade-right" data-aos-delay="200">
            <div class="featured-service-main">
              <div class="service-image-wrapper">
                <img src="<%=ctxPath%>/resources/assets/img/health/consultation-4.webp" alt="Premier Healthcare Services" class="img-fluid"
                  loading="lazy">
                <div class="service-overlay">
                  <div class="service-badge">
                    <i class="bi bi-heart-pulse"></i>
                    <span>Emergency Care</span>
                  </div>
                </div>
              </div>
              
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-left" data-aos-delay="300">
            <div class="services-sidebar">

              <div class="service-item" data-aos="fade-up" data-aos-delay="400">
                <div class="icon flex-shrink-0"><i class="bi bi-person-circle"></i></div>
                <div class="service-info">
                  <h4>Patient Dashboard</h4>
                  <p>Personal health tracking, medicine schedule management, and instant access to EHR history.</p>
                  
                </div>
              </div>

              <div class="service-item" data-aos="fade-up" data-aos-delay="500">
               <div class="icon flex-shrink-0"><i class="bi bi-person-badge-fill"></i></div>
                <div class="service-info">
                  <h4>Doctor Portal</h4>
                  <p>Comprehensive patient record search, digital prescription issuance, and clinical care coordination.</p>
                 
                </div>
              </div>

              <div class="service-item" data-aos="fade-up" data-aos-delay="600">
                <div class="icon flex-shrink-0"><i class="bi bi-flask"></i></div>
                <div class="service-info">
                  <h4>Laboratory Module</h4>
                  <p>Secure uploading of lab results, diagnostic report management, and real-time data sharing with providers.</p>
                  
                </div>
              </div>

    
            
    </section><!-- /Find A Doctor Section -->

    <!-- Call To Action Section -->
    <section id="call-to-action" class="call-to-action section light-background">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="hero-content">
          <div class="row align-items-center">

            <div class="col-lg-6">
              <div class="content-wrapper" data-aos="fade-up" data-aos-delay="200">
                <h1>Smart Medicine Alerts</h1>
                <p>Never miss a dose with intelligent notifications linked directly to your electronic health record. Syncs across all your devices for reliable medication adherence.</p>

               
              </div>
            </div>

            <div class="col-lg-6">
              <div class="image-container" data-aos="fade-left" data-aos-delay="300">
                <img src="<%=ctxPath%>/resources/assets/img/health/facilities-9.webp" alt="Medical Excellence" class="img-fluid">
              </div>
            </div>

          </div>
        </div>


      </div>

    </section>

  </main>

<%@include file="blocks/footer.jsp"%>