<%@include file="../blocks/userheader.jsp" %>

  <main class="main">
	<br><br><br><br><br>
	<h1>Upload Doctor Prescriptions</h1>
   
   	<div class="container">
   	
   	 <form action="<%=ctxPath%>/patient/uploadpres" enctype="multipart/form-data" method="post">
    	<input type="hidden" name="uploadby" value="<%=user.getRole()%>"/>
    	<div class="row mt-3">
    		<div class="col-xl-4 col-lg-4">
    			<label>Record Date</label>
    			<input type="date" class="form-control" name="date" required/>
    		</div>
    		<div class="col-xl-4 col-lg-4">
    			<label>Patient</label>
    			<select class="form-control" name="doctor" required>
    				<option value=''>Choose Patient</option>
    				<sp:forEach var="dt" items="${dlist}">
    					<option value="${dt.id}">${dt.name}</option>
    				</sp:forEach>
    			</select>
    		</div>
    		<div class="col-xl-4 col-lg-4">
    			<label>File</label>
    			<input type="file" class="form-control" name="file" required/>
    		</div>
    	</div>
    	<div class="row mt-3">
    		<div class="col-xl-8 col-lg-8">
    			<label>Description</label>
    			<input type="text" class="form-control" name="desc" required/>
    		</div>
    		<div class="col-xl-4 col-lg-4">
    			<button class="btn btn-primary">Save Record</button>
    		</div>
    	</div>
    
    </form>
   	</div> 
  </main>
  
<%@include file="../blocks/footer.jsp" %>      