<%@include file="../blocks/userheader.jsp" %>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    .main-dashboard {
        padding: 40px 0;
        background-color: #f8f9fa;
        min-height: 85vh;
        font-family: 'Poppins', sans-serif;
    }

    /* Fix for the overlapping text in your screenshot */
    .welcome-section {
        text-align: center;
        margin-bottom: 30px;
    }

    .welcome-text {
        font-size: 1.2rem;
        color: #555;
        margin-bottom: 5px;
        display: block;
    }

    .dashboard-title {
        font-size: 2.5rem;
        color: #2c3e50;
        font-weight: 700;
        margin: 0;
    }

    .card-container {
        display: flex;
        justify-content: center;
        gap: 25px;
        flex-wrap: wrap;
        margin-top: 40px;
    }

    .card {
        background: #ffffff;
        border-radius: 15px;
        padding: 35px 20px;
        width: 280px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
        border: none;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
    }

    .card h2 {
        font-size: 1.4rem;
        color: #333;
        margin-bottom: 25px;
    }

    /* Icon Circle using Font Awesome instead of broken images */
    .icon-circle {
        background-color: #eef5ff;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        margin: 0 auto 30px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .icon-circle i {
        font-size: 40px;
        color: #1a73e8;
    }

    .btn-action {
        display: inline-block;
        background-color: #1a73e8;
        color: #ffffff;
        padding: 12px 0;
        width: 100%;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        transition: background 0.3s ease;
    }

    .btn-action:hover {
        background-color: #1557b0;
        color: #fff;
    }
</style>

<main class="main-dashboard">
<br>
<br>
<br>
<br>
        <div class="card-container">
            

            <div class="card">
                <h2>Upload Record</h2>
                <div class="icon-circle">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                </div>
                <a href="<%=ctxPath%>/doctor/upload" class="btn-action">Upload Record</a>
            </div>

            <div class="card">
                <h2>View Records</h2>
                <div class="icon-circle">
                    <i class="fa-solid fa-file-medical"></i>
                </div>
                <a href="<%=ctxPath%>/doctor/view" class="btn-action">View Records</a>
            </div>
        </div>
    </div>
</main>
<%@include file="../blocks/footer.jsp" %>      